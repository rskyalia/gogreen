<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        $this->configureRateLimiting();
    }

    protected function configureRateLimiting(): void
    {
        // Rate limiter untuk login — 5 percobaan per menit per kombinasi email+IP
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)
                ->by($request->input('email').'|'.$request->ip())
                ->response(fn () => response()->json([
                    'message' => 'Terlalu banyak percobaan login. Coba lagi dalam 1 menit.',
                    'errors' => [],
                ], 429));
        });

        // Rate limiter untuk generate member-token — 10 per menit per user
        RateLimiter::for('member-token', function (Request $request) {
            return Limit::perMinute(10)
                ->by(optional($request->user())->id ?: $request->ip())
                ->response(fn () => response()->json([
                    'message' => 'Terlalu banyak permintaan token. Coba lagi sebentar.',
                    'code' => 'rate_limited',
                    'errors' => [],
                ], 429));
        });

        // Rate limiter untuk lookup member oleh petugas — 30 per menit per akun
        RateLimiter::for('member-lookup', function (Request $request) {
            return Limit::perMinute(30)
                ->by(optional($request->user())->id ?: $request->ip())
                ->response(fn () => response()->json([
                    'message' => 'Terlalu banyak percobaan lookup. Coba lagi dalam 1 menit.',
                    'code' => 'rate_limited',
                    'errors' => [],
                ], 429));
        });

        // Rate limiter untuk AI rekomendasi karya — 10 per menit per user (panggilan Gemini mahal)
        RateLimiter::for('ai-recommend', function (Request $request) {
            return Limit::perMinute(10)
                ->by(optional($request->user())->id ?: $request->ip())
                ->response(fn () => response()->json([
                    'message' => 'Terlalu banyak permintaan rekomendasi AI. Coba lagi sebentar.',
                    'errors' => [],
                ], 429));
        });

        // Rate limiter default API — 60 request/menit per user atau IP
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)
                ->by(optional($request->user())->id ?: $request->ip());
        });
    }
}
